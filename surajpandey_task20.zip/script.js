const services = [
  { name: "Dry Cleaning", price: 200 },
  { name: "Wash & Fold", price: 100 },
  { name: "Ironing", price: 30 },
  { name: "Stain Removal", price: 500 },
  { name: "Leather Cleaning", price: 999 }
];

let cart = [];
let total = 0;

// Show services
function loadServices() {
  let html = "";

  services.forEach((s, index) => {
    html += `
      <div class="item">
        <span>${s.name} - ₹${s.price}</span>
        <button class="add" onclick="addItem(${index})">Add</button>
      </div>
    `;
  });

  document.getElementById("serviceList").innerHTML = html;
}

// Add item
function addItem(index) {
  cart.push(services[index]);
  renderCart();
}

// Remove item
function removeItem(i) {
  cart.splice(i, 1);
  renderCart();
}

// Render cart
function renderCart() {
  let html = "";
  total = 0;

  cart.forEach((item, i) => {
    total += item.price;

    html += `
      <tr>
        <td>${i + 1}</td>
        <td>${item.name}</td>
        <td>₹${item.price} 
          <button class="remove" onclick="removeItem(${i})">X</button>
        </td>
      </tr>
    `;
  });

  document.getElementById("cartItems").innerHTML = html;
  document.getElementById("total").innerText = total;
}

loadServices();

const menuItems = document.querySelectorAll(".menu span");

menuItems.forEach(item => {
  item.addEventListener("click", function () {

    // Sab se active hatao
    menuItems.forEach(el => el.classList.remove("active"));

    // Current pe add karo
    this.classList.add("active");

  });
});