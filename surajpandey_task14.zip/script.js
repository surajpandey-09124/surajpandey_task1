function run(){

  let n = Number(document.getElementById("num").value);

  let output = "";

  // 1. Sum of first n numbers
  let sum = 0;
  for(let i=1;i<=n;i++){
    sum += i;
  }
  console.log("Sum of first " + n + " numbers:", sum);
  output += "Sum of first " + n + " numbers: " + sum + "\n";

  // 2. Table of n
  console.log("Table of", n);
  output += "Table of " + n + ":\n";
  for(let i=1;i<=10;i++){
    console.log(n + " x " + i + " = " + n*i);
    output += n + " x " + i + " = " + n*i + "\n";
  }

  // 3. Prime check
  let isPrime = true;
  if(n < 2) isPrime = false;

  for(let i=2;i<n;i++){
    if(n % i === 0){
      isPrime = false;
      break;
    }
  }
  console.log("Prime:", isPrime);
  output += "Is Prime: " + (isPrime ? "Yes" : "No") + "\n";

  // 4. Factors
  let factors = [];
  for(let i=1;i<=n;i++){
    if(n % i === 0){
      factors.push(i);
    }
  }
  console.log("Factors:", factors);
  output += "Factors: " + factors.join(", ") + "\n";

  // 5. Sum of digits
  let temp = n;
  let digitSum = 0;
  while(temp > 0){
    digitSum += temp % 10;
    temp = Math.floor(temp / 10);
  }
  console.log("Digit Sum:", digitSum);
  output += "Sum of digits: " + digitSum + "\n";

  // 6. Armstrong check
  temp = n;
  let arm = 0;
  let digits = n.toString().length;

  while(temp > 0){
    let d = temp % 10;
    arm += Math.pow(d, digits);
    temp = Math.floor(temp / 10);
  }

  let isArmstrong = arm === n;
  console.log("Armstrong:", isArmstrong);
  output += "Is Armstrong: " + (isArmstrong ? "Yes" : "No");

  document.getElementById("output").innerText = output;
}