function calculateCI(){

  let P = document.getElementById("p").value;
  let R = document.getElementById("r").value;
  let N = document.getElementById("n").value;
  let T = document.getElementById("t").value;

  // formula
  let A = P * Math.pow((1 + (R/100)/N), N*T);

  document.getElementById("result").innerText =
    "Amount after " + T + " years is: " + A.toFixed(2);
}