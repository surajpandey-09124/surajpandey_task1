// Arrow Function returning Promise
const divide = (a, b) => {
  return new Promise((resolve, reject) => {
    if (b === 0) {
      reject("Error: Division by zero is not allowed.");
    } else {
      resolve(a / b);
    }
  });
};

function run(){

  let a = Number(document.getElementById("num1").value);
  let b = Number(document.getElementById("num2").value);

  let output = "";

  // User input case
  output += `Dividing ${a} by ${b}...\n`;

  divide(a, b)
    .then(res => {
      console.log("Result:", res);
      output += "Result: " + res + "\n";
      document.getElementById("output").innerText = output;
    })
    .catch(err => {
      console.log(err);
      output += err + "\n";
      document.getElementById("output").innerText = output;
    });

  // 🔥 5 Dummy Test Cases
  let testCases = [
    [10,2],
    [10,0],
    [20,5],
    [15,3],
    [9,0]
  ];

  testCases.forEach(([x,y])=>{
    divide(x,y)
      .then(res => console.log(`Dividing ${x}/${y} =`, res))
      .catch(err => console.log(`Dividing ${x}/${y} ->`, err));
  });

}