// Student Array
let students = [
  {name:"Salmaan Ahmed", marks:38, class:"3rd", address:"India"},
  {name:"Riya Sharma", marks:85, class:"10th", address:"Delhi"},
  {name:"Rohan Patel", marks:70, class:"12th", address:"Mumbai"},
  {name:"Priya Singh", marks:95, class:"8th", address:"Bangalore"},
  {name:"Ankit Gupta", marks:60, class:"9th", address:"Kolkata"},
  {name:"Neha Verma", marks:80, class:"11th", address:"Chennai"},
  {name:"Manoj Kumar", marks:75, class:"10th", address:"Hyderabad"},
  {name:"Pooja Mishra", marks:88, class:"12th", address:"Pune"},
  {name:"Rajesh Singh", marks:92, class:"9th", address:"Jaipur"}
];

// Render function
function display(data){
  let container = document.getElementById("container");
  container.innerHTML = "";

  data.forEach(s => {
    container.innerHTML += `
      <div class="card">
        <p><b>Student Name:</b> ${s.name}</p>
        <p>Marks: ${s.marks}%</p>
        <p>Class: ${s.class}</p>
        <p>Address: ${s.address}</p>
      </div>
    `;
  });
}

// Filter function
function filterStudents(){
  let value = document.getElementById("search").value.toLowerCase();

  let filtered = students.filter(s =>
    s.name.toLowerCase().includes(value)
  );

  display(filtered);
}

// Initial load
display(students);