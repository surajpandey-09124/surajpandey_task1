let num1 = 5;
let num2 = 10;
let num3 = 7;

function check(){

  let num = document.getElementById("num").value;

  if(num % 2 === 0){
    document.getElementById("result").innerText =
      "The number " + num + " is even.";
  } else {
    document.getElementById("result").innerText =
      "The number " + num + " is odd.";
  }

  // console log (assignment requirement)
  if(num1 % 2 === 0){
    console.log("The number " + num1 + " is even.");
  } else {
    console.log("The number " + num1 + " is odd.");
  }

  if(num2 % 2 === 0){
    console.log("The number " + num2 + " is even.");
  } else {
    console.log("The number " + num2 + " is odd.");
  }

  if(num3 % 2 === 0){
    console.log("The number " + num3 + " is even.");
  } else {
    console.log("The number " + num3 + " is odd.");
  }
}