const services = [
  {
    name: "Dry Cleaning",
    price: 200,
    img: "https://images.unsplash.com/photo-1581578731548-c64695cc6952"
  },
  {
    name: "Leather Cleaning",
    price: 999,
    img: "https://images.unsplash.com/photo-1581578017420-bb2f7b5a41d2"
  }
];

let index = 0;
let total = 0;
let count = 1;

function showItem() {
  if (index >= services.length) {
    document.querySelector(".right").innerHTML = "<h3>No more items</h3>";
    return;
  }

  document.getElementById("img").src = services[index].img;
  document.getElementById("name").innerText = services[index].name;
  document.getElementById("price").innerText = "₹" + services[index].price;
}

function addItem() {
  let item = services[index];

  let row = `
    <tr>
      <td>${count}</td>
      <td>${item.name}</td>
      <td>₹${item.price}</td>
    </tr>
  `;

  document.getElementById("cart").innerHTML += row;

  total += item.price;
  document.getElementById("total").innerText = total;

  count++;
  index++;
  showItem();
}

function skipItem() {
  index++;
  showItem();
}

showItem();