function greet(){
  let name = document.getElementById("name").value;

  document.getElementById("heading").innerText = "Hello " + name;
}