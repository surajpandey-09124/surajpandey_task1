function run(){

  let input = document.getElementById("arr").value;

  // convert input string to array
  let arr = input.split(",").map(Number);

  let output = "Array: " + arr.join(", ") + "\n";

  // Max
  function findMax(a){
    let max = a[0];
    for(let i=1;i<a.length;i++){
      if(a[i] > max){
        max = a[i];
      }
    }
    return max;
  }

  // Sum
  const findSum = (a) => {
    let sum = 0;
    for(let i of a){
      sum += i;
    }
    return sum;
  };

  // Count Odd
  let countOdd = function(a){
    let count = 0;
    for(let i of a){
      if(i % 2 !== 0){
        count++;
      }
    }
    return count;
  };

  let max = findMax(arr);
  let sum = findSum(arr);
  let odd = countOdd(arr);

  console.log("Max:", max);
  console.log("Sum:", sum);
  console.log("Odd Count:", odd);

  output += "Max: " + max + "\n";
  output += "Sum: " + sum + "\n";
  output += "Odd Count: " + odd;

  document.getElementById("output").innerText = output;
}